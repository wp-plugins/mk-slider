MK Slider :  This is banner functionality for automatically changing banner images. Images fade-out and fade-in. It also contains the thumbnails for navigating the images.

Created By: Manoj Rana
Email : manoj_rana91986@live.com

== Installation ==

1. Upload the plugin to your /wp-content/plugins/ directory.

2. Activate the plugin through the 'Plugins' menu in WordPress.

3. Add the <?php if(function_exists('mk_slider')){mk_slider();} ?> code to your theme file where you 	   want the slider to appear.

